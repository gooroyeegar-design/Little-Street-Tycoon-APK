extends Node3D

# Little Street Tycoon - fully procedural, no external assets required.
# Designed as a real 3D/isometric mobile management game foundation.

var coins: float = 55.0
var served: int = 0
var level: int = 1
var products: int = 1
var workers_count: int = 0
var cook_stations: int = 1
var seats: int = 0
var reputation: float = 0.0
var last_save: int = 0

var player: Node3D
var player_target := Vector3.ZERO
var has_player_target := false
var camera: Camera3D
var world_root: Node3D
var shop_root: Node3D
var people_root: Node3D
var fx_root: Node3D
var ui: CanvasLayer
var coins_label: Label
var level_label: Label
var served_label: Label
var rep_label: Label
var mission_label: Label
var upgrade_panel: PanelContainer
var joystick_base: Control
var joystick_knob: Control
var joystick_active := false
var joystick_vector := Vector2.ZERO
var customers: Array = []
var workers: Array = []
var customer_timer := 0.0
var ambient_timer := 0.0
var construction_tween: Tween

const COLORS = [Color("#ef6b62"), Color("#5d9ee9"), Color("#f2c94c"), Color("#9b6bce"), Color("#55b58a")]
const HAIRS = [Color("#3b2921"), Color("#1f1d1b"), Color("#8a542f"), Color("#d9a441")]
const PRODUCTS = ["HOT DOG", "FRIES", "LEMONADE", "BURGER", "SHAKE"]

func _ready():
    randomize()
    last_save = Time.get_unix_time_from_system()
    _setup_environment()
    _build_world()
    _build_ui()
    _load_game()
    _apply_progression_visuals()
    _spawn_initial_customers()
    for i in workers_count:
        _spawn_worker(i)
    queue_redraw()

func mat(color: Color, roughness := 0.82, metallic := 0.0) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    m.metallic = metallic
    return m

func mesh_box(size: Vector3, color: Color, pos: Vector3, parent: Node3D = world_root, bevel := 0.0) -> MeshInstance3D:
    var n = MeshInstance3D.new()
    var b = BoxMesh.new()
    b.size = size
    n.mesh = b
    n.material_override = mat(color)
    n.position = pos
    n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    parent.add_child(n)
    return n

func mesh_cyl(radius: float, height: float, color: Color, pos: Vector3, parent: Node3D = world_root) -> MeshInstance3D:
    var n = MeshInstance3D.new()
    var c = CylinderMesh.new()
    c.top_radius = radius
    c.bottom_radius = radius
    c.height = height
    c.radial_segments = 12
    n.mesh = c
    n.material_override = mat(color)
    n.position = pos
    n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    parent.add_child(n)
    return n

func mesh_sphere(radius: float, color: Color, pos: Vector3, parent: Node3D = world_root) -> MeshInstance3D:
    var n = MeshInstance3D.new()
    var s = SphereMesh.new()
    s.radius = radius
    s.height = radius * 2.0
    s.radial_segments = 12
    s.rings = 6
    n.mesh = s
    n.material_override = mat(color)
    n.position = pos
    n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    parent.add_child(n)
    return n

func _setup_environment():
    var env = WorldEnvironment.new()
    var e = Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color("#9fd9e8")
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("#fff5df")
    e.ambient_light_energy = 0.75
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.glow_enabled = true
    e.glow_intensity = 0.55
    env.environment = e
    add_child(env)

    var sun = DirectionalLight3D.new()
    sun.light_color = Color("#fff1cf")
    sun.light_energy = 1.7
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 55.0
    sun.rotation_degrees = Vector3(-55, -35, 0)
    add_child(sun)

    var fill = DirectionalLight3D.new()
    fill.light_color = Color("#cce8ff")
    fill.light_energy = 0.45
    fill.rotation_degrees = Vector3(-35, 145, 0)
    add_child(fill)

func _build_world():
    world_root = Node3D.new()
    world_root.name = "World"
    add_child(world_root)
    shop_root = Node3D.new()
    shop_root.name = "Business"
    world_root.add_child(shop_root)
    people_root = Node3D.new()
    people_root.name = "People"
    world_root.add_child(people_root)
    fx_root = Node3D.new()
    fx_root.name = "Effects"
    world_root.add_child(fx_root)

    mesh_box(Vector3(48, 0.25, 48), Color("#75c951"), Vector3(0, -0.15, 0))
    # Main road and sidewalk.
    mesh_box(Vector3(48, 0.12, 4.5), Color("#aeb1b2"), Vector3(0, 0.02, -10))
    mesh_box(Vector3(4.5, 0.12, 48), Color("#aeb1b2"), Vector3(-11, 0.02, 0))
    mesh_box(Vector3(48, 0.06, 0.25), Color("#dedede"), Vector3(0, 0.1, -7.8))
    mesh_box(Vector3(0.25, 0.06, 48), Color("#dedede"), Vector3(-8.8, 0.1, 0))
    for x in [-20.0, -14.0, -8.0, -2.0, 4.0, 10.0, 16.0]:
        mesh_box(Vector3(2.4, 0.04, 0.16), Color("#f3f0dc"), Vector3(x, 0.11, -10))

    # Decorative park elements.
    for p in [Vector3(9,0,7),Vector3(14,0,4),Vector3(10,0,13),Vector3(-3,0,12),Vector3(16,0,12)]:
        _make_tree(p)

    _build_shop_shell()
    _build_decorations()

func _make_tree(p: Vector3):
    mesh_cyl(0.22, 1.3, Color("#80552f"), p + Vector3(0,0.65,0))
    mesh_sphere(1.05, Color("#4fae42"), p + Vector3(0,1.65,0))
    mesh_sphere(0.72, Color("#69c84e"), p + Vector3(0.5,1.5,0.1))

func _build_shop_shell():
    for c in shop_root.get_children(): c.queue_free()
    var floor = mesh_box(Vector3(13,0.25,9.5), Color("#ead4a5"), Vector3(0,0.16,0), shop_root)
    floor.scale = Vector3.ONE
    # Back building and side walls.
    mesh_box(Vector3(13,3.4,0.35), Color("#f2d27d"), Vector3(0,1.8,4.55), shop_root)
    mesh_box(Vector3(0.35,3.4,9.5), Color("#f0c96c"), Vector3(-6.35,1.8,0), shop_root)
    mesh_box(Vector3(0.35,3.4,9.5), Color("#f0c96c"), Vector3(6.35,1.8,0), shop_root)
    # Windows.
    for x in [-4.1, -1.4, 1.4, 4.1]:
        mesh_box(Vector3(1.8,1.45,0.12), Color("#a9d8e3"), Vector3(x,2.15,4.34), shop_root)
        mesh_box(Vector3(1.95,0.13,0.16), Color("#8b5c34"), Vector3(x,1.4,4.3), shop_root)
    # Front awning.
    for i in range(7):
        var col = Color("#fff2cf") if i % 2 == 0 else Color("#e8a83b")
        mesh_box(Vector3(1.8,0.12,1.15), col, Vector3(-5.4+i*1.8,3.25,-4.85), shop_root)
    # Main counter.
    mesh_box(Vector3(10.5,0.9,0.9), Color("#efc568"), Vector3(0,0.7,-3.4), shop_root)
    mesh_box(Vector3(10.5,0.16,0.16), Color("#9c6537"), Vector3(0,1.18,-3.85), shop_root)
    # Register.
    mesh_box(Vector3(0.65,0.55,0.55), Color("#3d4144"), Vector3(-4.3,1.35,-3.3), shop_root)
    mesh_box(Vector3(0.5,0.3,0.08), Color("#72d0df"), Vector3(-4.3,1.63,-3.55), shop_root)
    _build_cooking_stations()

func _build_cooking_stations():
    for i in cook_stations:
        var x = -4.0 + i * (8.0 / max(1,cook_stations-1)) if cook_stations > 1 else 0.0
        mesh_box(Vector3(1.35,0.75,1.25), Color("#666b70"), Vector3(x,0.75,-0.2), shop_root)
        mesh_cyl(0.32,0.08,Color("#f4b82e"),Vector3(x,1.18,-0.2),shop_root)
        mesh_cyl(0.22,0.04,Color("#f7d98c"),Vector3(x,1.23,-0.2),shop_root)

func _build_decorations():
    # tables and umbrellas unlocked progressively
    for i in seats:
        var row = int(i / 4)
        var col = i % 4
        var x = -4.3 + col * 2.9
        var z = 0.9 + row * 1.9
        mesh_cyl(0.12,0.65,Color("#85552e"),Vector3(x,0.38,z),shop_root)
        mesh_cyl(0.75,0.12,Color("#c88743"),Vector3(x,0.78,z),shop_root)
        if i % 4 == 1:
            mesh_cyl(0.07,2.2,Color("#83552e"),Vector3(x,1.75,z),shop_root)
            var umbrella = mesh_cyl(1.15,0.18,Color("#4c9dd8"),Vector3(x,2.85,z),shop_root)
            umbrella.scale.y = 0.4
    # planter boxes
    for x in [-5.2,5.2]:
        mesh_box(Vector3(0.8,0.45,0.8),Color("#b87943"),Vector3(x,0.35,3.5),shop_root)
        mesh_sphere(0.55,Color("#5ab34b"),Vector3(x,0.95,3.5),shop_root)

func _make_character(body_color: Color, hair_color: Color, role := "customer") -> Node3D:
    var g = Node3D.new()
    g.name = role.capitalize()
    people_root.add_child(g)
    mesh_cyl(0.32,0.68,body_color,Vector3(0,0.5,0),g)
    mesh_sphere(0.36,Color("#f1bd89"),Vector3(0,1.05,0),g)
    mesh_cyl(0.37,0.16,hair_color,Vector3(0,1.34,0),g)
    # tiny face marks
    var eye1=mesh_sphere(0.035,Color("#202020"),Vector3(-0.12,1.07,-0.335),g)
    var eye2=mesh_sphere(0.035,Color("#202020"),Vector3(0.12,1.07,-0.335),g)
    # arms
    mesh_cyl(0.10,0.58,body_color,Vector3(-0.39,0.52,0),g).rotation_degrees.z=-18
    mesh_cyl(0.10,0.58,body_color,Vector3(0.39,0.52,0),g).rotation_degrees.z=18
    return g

func _make_label(text: String, color := Color.WHITE, size := 42) -> Label:
    var l=Label.new()
    l.text=text
    l.add_theme_font_size_override("font_size",size)
    l.add_theme_color_override("font_color",color)
    l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    l.add_theme_constant_override("outline_size",8)
    l.add_theme_color_override("font_outline_color",Color(0.08,0.08,0.08,0.8))
    return l

func _billboard(text: String, parent: Node3D, y := 2.0):
    var holder=Label3D.new()
    holder.text=text
    holder.font_size=36
    holder.modulate=Color.WHITE
    holder.outline_size=12
    holder.outline_modulate=Color("#222222")
    holder.position=Vector3(0,y,0)
    holder.billboard=BaseMaterial3D.BILLBOARD_ENABLED
    parent.add_child(holder)
    return holder

func _spawn_customer(index := 0):
    if customers.size() >= 3 + level: return
    var g=_make_character(COLORS[randi()%COLORS.size()],HAIRS[randi()%HAIRS.size()])
    var order_index=min(products-1,randi_range(0,products-1))
    var label=_billboard(PRODUCTS[order_index]+"  ×1",g,2.0)
    var c={"node":g,"state":"enter","target":Vector3(-7.4+index*1.9,0,-4.8),"wait":18.0,"order":order_index,"label":label,"paid":false,"speed":1.7+randf()*0.45}
    g.position=Vector3(-11-randf()*4,0,-9.0)
    customers.append(c)

func _spawn_initial_customers():
    for i in 2:
        _spawn_customer(i)

func _spawn_worker(i: int):
    var g=_make_character(Color("#57b87b"),Color("#4a3228"),"worker")
    g.position=Vector3(-3.2+i*1.5,0,1.8)
    var label=_billboard("WORKER",g,1.9)
    label.modulate=Color("#bff3cc")
    workers.append({"node":g,"target":Vector3.ZERO,"state":"work","speed":2.1,"phase":randf()*3.0})

func _distance(a: Vector3,b: Vector3)->float:
    return Vector2(a.x,a.z).distance_to(Vector2(b.x,b.z))

func _move_character(g: Node3D,target:Vector3,speed:float,dt:float)->bool:
    var d=target-g.position
    d.y=0
    if d.length()<0.08:
        return true
    d=d.normalized()
    g.position += d*speed*dt
    g.position.y=0
    g.look_at(g.position+d,Vector3.UP)
    # subtle walk bounce
    g.position.y=abs(sin(Time.get_ticks_msec()*0.012))*0.035
    return false

func _process(delta):
    customer_timer += delta
    ambient_timer += delta
    _handle_player(delta)
    _update_customers(delta)
    _update_workers(delta)
    if customer_timer > max(1.3,3.2-level*0.09):
        customer_timer=0
        _spawn_customer(customers.size())
    if ambient_timer > 1.0:
        ambient_timer=0
        coins += workers_count * 0.65
        _update_ui()
        _save_game()
    _update_fx(delta)
    queue_redraw()

func _update_customers(delta):
    for i in range(customers.size()-1,-1,-1):
        var c=customers[i]
        var g:Node3D=c.node
        if not is_instance_valid(g):
            customers.remove_at(i); continue
        if c.state=="enter":
            if _move_character(g,c.target,c.speed,delta):
                c.state="waiting"
        elif c.state=="waiting":
            c.wait -= delta
            var can_serve=_distance(g.global_position,Vector3(0,0,-3.2))<2.4
            var player_help=_distance(g.global_position,player.global_position)<2.1
            if can_serve or player_help:
                c.state="served"
                _serve_customer(c)
        elif c.state=="served":
            var out=Vector3(-11,0,-9)
            if _move_character(g,out,c.speed*1.25,delta):
                g.queue_free();customers.remove_at(i)
        if c.wait<=0 and c.state=="waiting":
            c.state="served"
            _serve_customer(c,true)

func _serve_customer(c, unhappy:=false):
    if c.paid: return
    c.paid=true
    if unhappy:
        coins += 1.0
        reputation=max(0,reputation-0.4)
    else:
        var earn=6.0 + products*2.0 + level*0.55
        coins += earn
        served += 1
        reputation += 0.25
        _coin_pop(c.node.global_position,earn)
        _check_level()

func _update_workers(delta):
    for w in workers:
        if not is_instance_valid(w.node): continue
        var target=Vector3(0,0,-0.2)
        if customers.size()>0:
            var best=customers[0]
            target=best.node.position
        w.target=target
        _move_character(w.node,target,w.speed,delta)

func _coin_pop(pos:Vector3,amount:float):
    var l=Label3D.new()
    l.text="+"+str(int(amount))+" coins"
    l.font_size=46
    l.outline_size=12
    l.modulate=Color("#ffe16a")
    l.position=pos+Vector3(0,1.6,0)
    l.billboard=BaseMaterial3D.BILLBOARD_ENABLED
    fx_root.add_child(l)
    var tw=create_tween()
    tw.tween_property(l,"position",l.position+Vector3(0,1.2,0),0.7).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tw.parallel().tween_property(l,"modulate",Color(1,0.88,0.3,0),0.7)
    tw.tween_callback(l.queue_free)

func _update_fx(_delta):
    pass

func _check_level():
    var needed=5+level*5
    if served>=needed:
        level+=1
        reputation+=2
        if level==2: products=2
        if level==3: cook_stations=2
        if level==4: products=3
        if level==5: seats=4
        if level==6: workers_count+=1;_spawn_worker(workers_count-1)
        if level==7: cook_stations=3
        if level==8: seats=8
        if level==9: products=4
        if level==10: workers_count+=1;_spawn_worker(workers_count-1)
        _apply_progression_visuals()
        _big_notification("LEVEL "+str(level),"Your street kitchen is growing")

func _apply_progression_visuals():
    _build_shop_shell()
    _build_decorations()
    if level>=5:
        _add_side_extension()
    if level>=8:
        _add_delivery_zone()

func _add_side_extension():
    mesh_box(Vector3(4.8,2.9,6.0),Color("#f6d88c"),Vector3(9,1.5,1.5),shop_root)
    mesh_box(Vector3(4.5,1.2,0.3),Color("#a9d8e3"),Vector3(9,2.1,-1.2),shop_root)
    mesh_box(Vector3(5.0,0.15,0.7),Color("#8d5c35"),Vector3(9,0.6,-1.8),shop_root)

func _add_delivery_zone():
    mesh_box(Vector3(4.2,0.25,3.2),Color("#dbd0bb"),Vector3(9,0.16,5.0),world_root)
    var van=mesh_box(Vector3(2.8,1.1,1.6),Color("#4d9fda"),Vector3(9,0.7,5.0),world_root)
    mesh_cyl(0.45,0.25,Color("#25292b"),Vector3(8.2,0.35,5.8),world_root).rotation_degrees.x=90
    mesh_cyl(0.45,0.25,Color("#25292b"),Vector3(9.8,0.35,5.8),world_root).rotation_degrees.x=90

func _build_ui():
    ui=CanvasLayer.new()
    add_child(ui)
    var top=ColorRect.new();top.color=Color("#171a1eE8");top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE);top.custom_minimum_size=Vector2(0,88);ui.add_child(top)
    var title=_make_label("LITTLE STREET KITCHEN",Color("#fff4d6"),28);title.position=Vector2(22,8);top.add_child(title)
    coins_label=_make_label("55",Color("#ffe17b"),26);coins_label.position=Vector2(24,48);top.add_child(coins_label)
    served_label=_make_label("Served 0",Color.WHITE,21);served_label.position=Vector2(150,50);top.add_child(served_label)
    level_label=_make_label("LV 1",Color("#8ed0ff"),24);level_label.position=Vector2(310,47);top.add_child(level_label)
    rep_label=_make_label("Rep 0",Color("#9ff0ba"),20);rep_label.position=Vector2(405,51);top.add_child(rep_label)

    var up=Button.new();up.text="UPGRADES";up.position=Vector2(790,17);up.size=Vector2(250,54);up.add_theme_font_size_override("font_size",22);top.add_child(up);up.pressed.connect(_toggle_upgrades)
    mission_label=_make_label("MISSION: Serve 5 customers",Color.WHITE,20);mission_label.position=Vector2(24,102);ui.add_child(mission_label)

    _build_joystick()
    _build_upgrade_panel()
    _update_ui()

func _build_joystick():
    joystick_base=Panel.new();joystick_base.position=Vector2(32,1530);joystick_base.size=Vector2(180,180);ui.add_child(joystick_base)
    var sb=StyleBoxFlat.new();sb.bg_color=Color(1,1,1,0.12);sb.border_color=Color(1,1,1,0.3);sb.set_corner_radius_all(90);joystick_base.add_theme_stylebox_override("panel",sb)
    joystick_knob=Panel.new();joystick_knob.position=Vector2(57,57);joystick_knob.size=Vector2(66,66);joystick_base.add_child(joystick_knob)
    var sk=StyleBoxFlat.new();sk.bg_color=Color(1,1,1,0.52);sk.set_corner_radius_all(33);joystick_knob.add_theme_stylebox_override("panel",sk)
    joystick_base.gui_input.connect(_joystick_input)

func _joystick_input(event):
    if event is InputEventScreenTouch:
        joystick_active=event.pressed
        if not joystick_active:
            joystick_vector=Vector2.ZERO
            joystick_knob.position=Vector2(57,57)
    elif event is InputEventScreenDrag and joystick_active:
        var center=joystick_base.size/2
        var v=event.position-center
        v=v.limit_length(58)
        joystick_vector=v/58.0
        joystick_knob.position=center+v-joystick_knob.size/2

func _build_upgrade_panel():
    upgrade_panel=PanelContainer.new();upgrade_panel.position=Vector2(190,190);upgrade_panel.size=Vector2(700,1120);upgrade_panel.visible=false;ui.add_child(upgrade_panel)
    var style=StyleBoxFlat.new();style.bg_color=Color("#f4f0e7");style.corner_radius_top_left=28;style.corner_radius_top_right=28;style.corner_radius_bottom_left=28;style.corner_radius_bottom_right=28;style.shadow_color=Color(0,0,0,0.35);style.shadow_size=22
    upgrade_panel.add_theme_stylebox_override("panel",style)
    var box=VBoxContainer.new();box.add_theme_constant_override("separation",12);upgrade_panel.add_child(box)
    var h=_make_label("BUSINESS UPGRADES",Color("#2d2925"),30);box.add_child(h)
    var sub=_make_label("Every upgrade changes the world.",Color("#746c63"),18);box.add_child(sub)
    _upgrade_button(box,"Hire a worker","A real worker joins the shop",70,func():
        if coins>=70:
            coins-=70;workers_count+=1;_spawn_worker(workers_count-1);_toast("New worker hired")
    )
    _upgrade_button(box,"Add cooking station","Prepare more orders at once",95,func():
        if coins>=95:
            coins-=95;cook_stations+=1;_apply_progression_visuals();_toast("New cooking station built")
    )
    _upgrade_button(box,"Expand seating","Customers can stay and spend more",130,func():
        if coins>=130:
            coins-=130;seats+=4;_apply_progression_visuals();_toast("New seating area built")
    )
    _upgrade_button(box,"Street expansion","Unlock another physical section",250,func():
        if coins>=250:
            coins-=250;level+=1;_apply_progression_visuals();_toast("The street is expanding")
    )
    var close=Button.new();close.text="CLOSE";close.custom_minimum_size=Vector2(0,64);box.add_child(close);close.pressed.connect(_toggle_upgrades)

func _upgrade_button(parent,title,desc,cost,action):
    var b=Button.new();b.text=title+"   —   "+str(cost)+" coins\n"+desc;b.custom_minimum_size=Vector2(0,100);b.add_theme_font_size_override("font_size",22);parent.add_child(b);b.pressed.connect(action)

func _toggle_upgrades():
    upgrade_panel.visible=!upgrade_panel.visible

func _handle_player(delta):
    if not is_instance_valid(player):
        player=_make_character(Color("#ff9b61"),Color("#4a3025"),"player")
        player.position=Vector3(0,0,2.8)
        player_target=player.position
    var v=joystick_vector
    if Input.is_action_pressed("move_left"): v.x-=1
    if Input.is_action_pressed("move_right"): v.x+=1
    if Input.is_action_pressed("move_up"): v.y-=1
    if Input.is_action_pressed("move_down"): v.y+=1
    if v.length()>0.05:
        v=v.normalized()
        player.position.x+=v.x*4.2*delta
        player.position.z+=v.y*4.2*delta
        player.look_at(player.position+Vector3(v.x,0,v.y),Vector3.UP)
        has_player_target=false
    elif has_player_target:
        if _move_character(player,player_target,4.2,delta): has_player_target=false
    player.position.x=clamp(player.position.x,-5.5,10.0)
    player.position.z=clamp(player.position.z,-5.5,7.5)

func _unhandled_input(event):
    if event is InputEventScreenTouch and event.pressed:
        if joystick_base and joystick_base.get_global_rect().has_point(event.position): return
        var from=event.position
        var viewport=get_viewport().get_visible_rect().size
        # Screen-to-ground approximation for isometric camera.
        var nx=(from.x/viewport.x-0.5)*22.0
        var nz=(from.y/viewport.y-0.52)*18.0
        player_target=Vector3(clamp(nx,-5.5,10.0),0,clamp(nz,-5.5,7.5))
        has_player_target=true
    elif event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
        var vp=get_viewport().get_visible_rect().size
        var nx=(event.position.x/vp.x-0.5)*22.0
        var nz=(event.position.y/vp.y-0.52)*18.0
        player_target=Vector3(clamp(nx,-5.5,10.0),0,clamp(nz,-5.5,7.5))
        has_player_target=true

func _update_ui():
    if not coins_label:return
    coins_label.text=str(int(coins))+" coins"
    served_label.text="Served "+str(served)
    level_label.text="LV "+str(level)
    rep_label.text="Rep "+str(int(reputation))
    mission_label.text="MISSION: Serve "+str(5+level*5)+" customers  •  "+str(served)+"/"+str(5+level*5)

func _big_notification(a,b):
    var shade=ColorRect.new();shade.color=Color(0,0,0,0.25);shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);shade.mouse_filter=Control.MOUSE_FILTER_IGNORE;ui.add_child(shade)
    var box=Panel.new();box.position=Vector2(90,680);box.size=Vector2(900,330);ui.add_child(box)
    var st=StyleBoxFlat.new();st.bg_color=Color("#fff4d9");st.corner_radius_top_left=36;st.corner_radius_top_right=36;st.corner_radius_bottom_left=36;st.corner_radius_bottom_right=36;box.add_theme_stylebox_override("panel",st)
    var t=_make_label(a,Color("#d88931"),58);t.position=Vector2(0,50);t.size=Vector2(900,80);box.add_child(t)
    var s=_make_label(b,Color("#3e352d"),25);s.position=Vector2(40,145);s.size=Vector2(820,70);box.add_child(s)
    var ok=Button.new();ok.text="LET'S GO";ok.position=Vector2(290,230);ok.size=Vector2(320,65);box.add_child(ok)
    ok.pressed.connect(func():box.queue_free();shade.queue_free())

func _toast(text):
    var t=_make_label(text,Color("#fff4d0"),24);t.position=Vector2(300,1120);t.size=Vector2(480,70);ui.add_child(t)
    var tw=create_tween();tw.tween_property(t,"position",t.position+Vector2(0,-80),0.9);tw.parallel().tween_property(t,"modulate",Color(1,1,1,0),0.9);tw.tween_callback(t.queue_free)

func _save_game():
    var data={"coins":coins,"served":served,"level":level,"products":products,"workers":workers_count,"stations":cook_stations,"seats":seats,"rep":reputation,"time":Time.get_unix_time_from_system()}
    var f=FileAccess.open("user://save.json",FileAccess.WRITE)
    if f:f.store_string(JSON.stringify(data));f.close()

func _load_game():
    if not FileAccess.file_exists("user://save.json"): return
    var f=FileAccess.open("user://save.json",FileAccess.READ)
    var data=JSON.parse_string(f.get_as_text());f.close()
    if typeof(data)==TYPE_DICTIONARY:
        coins=float(data.get("coins",coins));served=int(data.get("served",served));level=int(data.get("level",level));products=int(data.get("products",products));workers_count=int(data.get("workers",workers_count));cook_stations=int(data.get("stations",cook_stations));seats=int(data.get("seats",seats));reputation=float(data.get("rep",reputation))
        var away=max(0,Time.get_unix_time_from_system()-int(data.get("time",Time.get_unix_time_from_system())))
        var offline=min(7200,away)*max(1,workers_count)*0.55
        if offline>5:
            coins+=offline
            call_deferred("_toast","Offline earnings +"+str(int(offline))+" coins")

func _notification(what):
    if what==NOTIFICATION_WM_CLOSE_REQUEST or what==NOTIFICATION_APPLICATION_PAUSED:
        _save_game()

